<?php
use PHPUnit\Framework\TestCase;

final class ValidacionesTest extends TestCase {
    public function testUsuarioValidoNoDaError(): void {
    $datos = ['primer_nombre'=>'Juan','primer_apellido'=>'Perez','email'=>'juan@email.com','rol'=>'Vecino','contrasena'=>'1234'];
    $this->assertNull(validarUsuario($datos));
}
    

    public function testUsuarioConCorreoInvalidoDaError(): void {
        $datos = ['primer_nombre'=>'Juan','primer_apellido'=>'Perez','email'=>'juan','rol'=>'Vecino'];
        $this->assertSame('El correo no es válido.', validarUsuario($datos));
    }

    public function testUsuarioEditadoSinNuevaContrasenaEsValido(): void {
        $datos = ['primer_nombre'=>'Juan','primer_apellido'=>'Perez','email'=>'juan@email.com','rol'=>'Vecino','contrasena'=>''];
        $this->assertNull(validarUsuario($datos, true));
    }

    public function testUsuarioEditadoConContrasenaCortaDaError(): void {
        $datos = ['primer_nombre'=>'Juan','primer_apellido'=>'Perez','email'=>'juan@email.com','rol'=>'Vecino','contrasena'=>'123'];
        $this->assertSame('La contraseña debe tener al menos 4 caracteres.', validarUsuario($datos, true));
    }

    public function testRolInvalidoDaError(): void {
        $datos = ['primer_nombre'=>'Juan','primer_apellido'=>'Perez','email'=>'juan@email.com','rol'=>'Invitado'];
        $this->assertSame('El rol no es válido.', validarUsuario($datos));
    }

    public function testContenedorValido(): void {
        $datos = ['ubicacion'=>'18 de Julio 123','estado'=>'Funcional','capacidad'=>1000];
        $this->assertNull(validarContenedor($datos));
    }

    public function testContenedorSinUbicacionDaError(): void {
        $datos = ['ubicacion'=>'','estado'=>'Funcional','capacidad'=>1000];
        $this->assertSame('La ubicación es obligatoria.', validarContenedor($datos));
    }

    public function testContenedorConCapacidadCeroDaError(): void {
        $datos = ['ubicacion'=>'18 de Julio 123','estado'=>'Funcional','capacidad'=>0];
        $this->assertSame('La capacidad debe ser mayor a 0.', validarContenedor($datos));
    }

    public function testCamionConCapacidadNegativaDaError(): void {
        $datos = ['matricula'=>'SIR-10','estado'=>'Operativo','capacidad_carga'=>-10];
        $this->assertSame('La capacidad de carga debe ser mayor a 0.', validarCamion($datos));
    }

    public function testCentroValido(): void {
        $this->assertNull(validarCentro(['nombre'=>'Centro Norte','ubicacion'=>'Av. Norte 100']));
    }

    public function testMaquinariaValida(): void {
        $this->assertNull(validarMaquinaria(['nombre'=>'Pala 01','tipo'=>'Pala cargadora','estado'=>'Operativa']));
    }
}
