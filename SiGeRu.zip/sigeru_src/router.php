<?php

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);


/* Archivos PHP de la carpeta principal */
if (substr($uri, -4) === '.php') {

    $archivo = __DIR__ . $uri;

    if (file_exists($archivo)) {
        return false;
    }
}


/* Página principal */
if ($uri === '/' || $uri === '/index.html') {

    $archivo = __DIR__ . '/frontend/index.html';

    header('Content-Type: text/html; charset=utf-8');

    readfile($archivo);

    exit;
}


/* API */
if (strpos($uri, '/api/') === 0) {

    $archivo = __DIR__ . $uri;

    if (file_exists($archivo)) {
        return false;
    }
}


/* Páginas HTML */
if (strpos($uri, '/pages/') === 0) {

    $archivo = __DIR__ . '/frontend' . $uri;

    if (file_exists($archivo)) {

        header('Content-Type: text/html; charset=utf-8');

        readfile($archivo);

        exit;
    }
}


/* CSS */
if (strpos($uri, '/css/') === 0) {

    $archivo = __DIR__ . '/frontend' . $uri;

    if (file_exists($archivo)) {

        header('Content-Type: text/css; charset=utf-8');

        readfile($archivo);

        exit;
    }
}


/* JavaScript */
if (strpos($uri, '/js/') === 0) {

    $archivo = __DIR__ . '/frontend' . $uri;

    if (file_exists($archivo)) {

        header('Content-Type: application/javascript; charset=utf-8');

        readfile($archivo);

        exit;
    }
}


/* Otros archivos */
$archivo = __DIR__ . '/frontend' . $uri;

if (file_exists($archivo) && is_file($archivo)) {
    return false;
}


/* No encontrado */
http_response_code(404);

echo "Not Found";