<?php
function responder($datos = [], $codigo = 200) {
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function entradaJSON() {
    $contenido = file_get_contents('php://input');
    $datos = json_decode($contenido, true);
    return is_array($datos) ? $datos : [];
}

function usuarioActual(PDO $pdo) {
    if (!isset($_SESSION['usuario_id'])) return null;
    $stmt = $pdo->prepare('SELECT id_usuario, primer_nombre, primer_apellido, email, rol FROM usuarios WHERE id_usuario = ?');
    $stmt->execute([$_SESSION['usuario_id']]);
    return $stmt->fetch() ?: null;
}

function exigirLogin(PDO $pdo) {
    $usuario = usuarioActual($pdo);
    if (!$usuario) responder(['ok' => false, 'error' => 'Debes iniciar sesión.'], 401);
    return $usuario;
}

function exigirRol(PDO $pdo, $roles) {
    $usuario = exigirLogin($pdo);
    if (!in_array($usuario['rol'], $roles, true)) {
        responder(['ok' => false, 'error' => 'No tienes permiso para realizar esta acción.'], 403);
    }
    return $usuario;
}

function limpiarTexto($valor) {
    return trim((string)$valor);
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validarUsuario($datos, $esEdicion = false) {
    $roles = ['Administrador', 'Vecino', 'Cuadrilla', 'Operario'];
    if (limpiarTexto($datos['primer_nombre'] ?? '') === '') return 'El nombre es obligatorio.';
    if (limpiarTexto($datos['primer_apellido'] ?? '') === '') return 'El apellido es obligatorio.';
    if (!validarEmail($datos['email'] ?? '')) return 'El correo no es válido.';
    if (!in_array($datos['rol'] ?? '', $roles, true)) return 'El rol no es válido.';
    if (!$esEdicion && strlen($datos['contrasena'] ?? '') < 4) return 'La contraseña debe tener al menos 4 caracteres.';
    if ($esEdicion && isset($datos['contrasena']) && $datos['contrasena'] !== '' && strlen($datos['contrasena']) < 4) return 'La contraseña debe tener al menos 4 caracteres.';
    return null;
}

function validarContenedor($datos) {
    if (limpiarTexto($datos['ubicacion'] ?? '') === '') return 'La ubicación es obligatoria.';
    if (limpiarTexto($datos['estado'] ?? '') === '') return 'El estado es obligatorio.';
    if (!is_numeric($datos['capacidad'] ?? null) || (float)$datos['capacidad'] <= 0) return 'La capacidad debe ser mayor a 0.';
    return null;
}

function validarCamion($datos) {
    if (limpiarTexto($datos['matricula'] ?? '') === '') return 'La matrícula es obligatoria.';
    if (limpiarTexto($datos['estado'] ?? '') === '') return 'El estado es obligatorio.';
    if (!is_numeric($datos['capacidad_carga'] ?? null) || (float)$datos['capacidad_carga'] <= 0) return 'La capacidad de carga debe ser mayor a 0.';
    return null;
}

function validarCentro($datos) {
    if (limpiarTexto($datos['nombre'] ?? '') === '') return 'El nombre es obligatorio.';
    if (limpiarTexto($datos['ubicacion'] ?? '') === '') return 'La ubicación es obligatoria.';
    return null;
}

function validarMaquinaria($datos) {
    if (limpiarTexto($datos['nombre'] ?? '') === '') return 'El nombre es obligatorio.';
    if (limpiarTexto($datos['tipo'] ?? '') === '') return 'El tipo es obligatorio.';
    if (limpiarTexto($datos['estado'] ?? '') === '') return 'El estado es obligatorio.';
    return null;
}
