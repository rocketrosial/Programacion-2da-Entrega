<?php
require_once __DIR__ . '/../config/init.php';

$metodo = $_SERVER['REQUEST_METHOD'];
$recurso = $_GET['recurso'] ?? '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$datos = entradaJSON();

$config = [
    'contenedores' => [
        'tabla' => 'contenedores', 'id' => 'id_contenedor',
        'roles_get' => ['Administrador','Operario','Cuadrilla','Vecino'],
        'roles_write' => ['Administrador','Operario'],
        'validar' => 'validarContenedor' ],
    'camiones' => [
        'tabla' => 'camiones', 'id' => 'id_camion',
        'roles_get' => ['Administrador','Operario','Cuadrilla'],
        'roles_write' => ['Administrador','Operario'],
        'validar' => 'validarCamion'
    ],
    'centros' => [
        'tabla' => 'centro_acopio', 'id' => 'id_centro',
        'roles_get' => ['Administrador','Operario','Cuadrilla'],
        'roles_write' => ['Administrador','Operario'],
        'validar' => 'validarCentro'
    ],
    'maquinaria' => [
        'tabla' => 'maquinaria', 'id' => 'id_maquinaria',
        'roles_get' => ['Administrador','Operario','Cuadrilla'],
        'roles_write' => ['Administrador','Operario'],
        'validar' => 'validarMaquinaria'
    ]
];

if (isset($config[$recurso])) {
    $c = $config[$recurso];
    if ($metodo === 'GET') {
        exigirRol($pdo, $c['roles_get']);
        $stmt = $pdo->query("SELECT * FROM {$c['tabla']} ORDER BY {$c['id']} DESC");
        responder(['ok' => true, 'datos' => $stmt->fetchAll()]);
    }

    exigirRol($pdo, $c['roles_write']);
    if ($metodo === 'POST') {
        $error = call_user_func($c['validar'], $datos);
        if ($error) responder(['ok' => false, 'error' => $error], 422);
        try {
            if ($recurso === 'contenedores') {
                $stmt = $pdo->prepare('INSERT INTO contenedores (zona_incidencia, fecha_deteccion, estado, capacidad, ubicacion, zona, calle, id_residuo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$datos['zona_incidencia'] ?? '', $datos['fecha_deteccion'] ?? date('Y-m-d'), $datos['estado'], $datos['capacidad'], $datos['ubicacion'], $datos['zona'] ?? '', $datos['calle'] ?? '', $datos['id_residuo'] ?? null]);
            } elseif ($recurso === 'camiones') {
                $stmt = $pdo->prepare('INSERT INTO camiones (matricula, disponibilidad, estado, capacidad_carga, fecha_asignacion, hora_inicio, hora_fin) VALUES (?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([$datos['matricula'], $datos['disponibilidad'] ?? 'Disponible', $datos['estado'], $datos['capacidad_carga'], $datos['fecha_asignacion'] ?? null, $datos['hora_inicio'] ?? null, $datos['hora_fin'] ?? null]);
            } elseif ($recurso === 'centros') {
                $stmt = $pdo->prepare('INSERT INTO centro_acopio (nombre, ubicacion) VALUES (?, ?)');
                $stmt->execute([$datos['nombre'], $datos['ubicacion']]);
            } else {
                $stmt = $pdo->prepare('INSERT INTO maquinaria (estado, tipo, nombre) VALUES (?, ?, ?)');
                $stmt->execute([$datos['estado'], $datos['tipo'], $datos['nombre']]);
            }
            responder(['ok' => true, 'mensaje' => 'Registro creado correctamente.'], 201);
        } catch (PDOException $e) {
            responder(['ok' => false, 'error' => 'No se pudo crear el registro. Puede existir un dato repetido.'], 409);
        }
    }

    if ($id <= 0) responder(['ok' => false, 'error' => 'Falta el ID.'], 400);
    if ($metodo === 'DELETE') {
        $stmt = $pdo->prepare("DELETE FROM {$c['tabla']} WHERE {$c['id']} = ?");
        try { $stmt->execute([$id]); } catch (PDOException $e) { responder(['ok'=>false,'error'=>'No se puede eliminar porque tiene datos relacionados.'],409); }
        responder(['ok' => true, 'mensaje' => $stmt->rowCount() ? 'Registro eliminado.' : 'No encontrado.']);
    }
    if ($metodo === 'PUT') {
        $error = call_user_func($c['validar'], $datos);
        if ($error) responder(['ok' => false, 'error' => $error], 422);
        try {
            if ($recurso === 'contenedores') {
                $stmt = $pdo->prepare('UPDATE contenedores SET zona_incidencia=?, fecha_deteccion=?, estado=?, capacidad=?, ubicacion=?, zona=?, calle=?, id_residuo=? WHERE id_contenedor=?');
                $stmt->execute([$datos['zona_incidencia'] ?? '', $datos['fecha_deteccion'] ?? null, $datos['estado'], $datos['capacidad'], $datos['ubicacion'], $datos['zona'] ?? '', $datos['calle'] ?? '', $datos['id_residuo'] ?? null, $id]);
            } elseif ($recurso === 'camiones') {
                $stmt = $pdo->prepare('UPDATE camiones SET matricula=?, disponibilidad=?, estado=?, capacidad_carga=?, fecha_asignacion=?, hora_inicio=?, hora_fin=? WHERE id_camion=?');
                $stmt->execute([$datos['matricula'], $datos['disponibilidad'] ?? 'Disponible', $datos['estado'], $datos['capacidad_carga'], $datos['fecha_asignacion'] ?? null, $datos['hora_inicio'] ?? null, $datos['hora_fin'] ?? null, $id]);
            } elseif ($recurso === 'centros') {
                $stmt = $pdo->prepare('UPDATE centro_acopio SET nombre=?, ubicacion=? WHERE id_centro=?');
                $stmt->execute([$datos['nombre'], $datos['ubicacion'], $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE maquinaria SET estado=?, tipo=?, nombre=? WHERE id_maquinaria=?');
                $stmt->execute([$datos['estado'], $datos['tipo'], $datos['nombre'], $id]);
            }
            responder(['ok' => true, 'mensaje' => 'Registro actualizado.']);
        } catch (PDOException $e) {
            responder(['ok' => false, 'error' => 'No se pudo actualizar el registro.'], 409);
        }
    }
}

if ($recurso === 'incidencias') {
    if ($metodo === 'GET') {
        $usuario = exigirLogin($pdo);
        if ($usuario['rol'] === 'Vecino') {
            $stmt = $pdo->prepare('SELECT i.*, c.ubicacion, c.zona FROM incidencias i JOIN contenedores c ON c.id_contenedor=i.id_contenedor WHERE i.id_usuario=? ORDER BY i.id_incidencia DESC');
            $stmt->execute([$usuario['id_usuario']]);
        } else {
            $stmt = $pdo->query('SELECT i.*, c.ubicacion, c.zona FROM incidencias i JOIN contenedores c ON c.id_contenedor=i.id_contenedor ORDER BY i.id_incidencia DESC');
        }
        responder(['ok'=>true,'datos'=>$stmt->fetchAll()]);
    }
    if ($metodo === 'POST') {
        $usuario = exigirRol($pdo, ['Administrador','Operario','Vecino']);
        $idContenedor = (int)($datos['id_contenedor'] ?? 0);
        if ($idContenedor <= 0 || limpiarTexto($datos['descripcion'] ?? '') === '') responder(['ok'=>false,'error'=>'Selecciona un contenedor y describe el problema.'],422);
        $stmt = $pdo->prepare('SELECT id_contenedor FROM contenedores WHERE id_contenedor=?'); $stmt->execute([$idContenedor]);
        if (!$stmt->fetch()) responder(['ok'=>false,'error'=>'El contenedor no existe.'],404);
        $stmt = $pdo->prepare('INSERT INTO incidencias (id_contenedor, id_usuario, prioridad, fecha, descripcion, estado) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$idContenedor, $usuario['id_usuario'], $datos['prioridad'] ?? 'Media', $datos['fecha'] ?? date('Y-m-d'), limpiarTexto($datos['descripcion']), 'Pendiente']);
        responder(['ok'=>true,'mensaje'=>'Incidencia registrada correctamente.'],201);
    }
    if ($metodo === 'PUT') {
        exigirRol($pdo, ['Administrador','Operario','Cuadrilla']);
        if ($id <= 0) responder(['ok'=>false,'error'=>'Falta el ID de la incidencia.'],400);
        $stmt = $pdo->prepare('UPDATE incidencias SET prioridad=?, estado=?, descripcion=? WHERE id_incidencia=?');
        $stmt->execute([$datos['prioridad'] ?? 'Media', $datos['estado'] ?? 'Pendiente', limpiarTexto($datos['descripcion'] ?? ''), $id]);
        responder(['ok'=>true,'mensaje'=>'Incidencia actualizada.']);
    }
    if ($metodo === 'DELETE') {
        exigirRol($pdo, ['Administrador','Operario']);
        if ($id <= 0) responder(['ok'=>false,'error'=>'Falta el ID de la incidencia.'],400);
        $stmt=$pdo->prepare('DELETE FROM incidencias WHERE id_incidencia=?'); $stmt->execute([$id]);
        responder(['ok'=>true,'mensaje'=>'Incidencia eliminada.']);
    }
}

responder(['ok'=>false,'error'=>'Recurso u operación no disponible.'],404);
