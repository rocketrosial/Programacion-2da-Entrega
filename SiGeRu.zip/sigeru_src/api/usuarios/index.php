<?php
require_once __DIR__ . '/../config/init.php';

$metodo = $_SERVER['REQUEST_METHOD'];
$accion = $_GET['accion'] ?? '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$datos = entradaJSON();

if ($metodo === 'POST' && $accion === 'register') {
    if (strlen($datos['contrasena'] ?? '') < 4) responder(['ok' => false, 'error' => 'La contraseña debe tener al menos 4 caracteres.'], 422);
    $error = validarUsuario(array_merge($datos, ['rol' => 'Vecino']));
    if ($error) responder(['ok' => false, 'error' => $error], 422);
    try {
        $stmt = $pdo->prepare('INSERT INTO usuarios (primer_nombre, primer_apellido, email, contrasena, rol, zona) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            limpiarTexto($datos['primer_nombre']), limpiarTexto($datos['primer_apellido']),
            limpiarTexto($datos['email']), password_hash($datos['contrasena'], PASSWORD_DEFAULT),
            'Vecino', limpiarTexto($datos['zona'] ?? '')
        ]);
        responder(['ok' => true, 'mensaje' => 'Cuenta creada correctamente.'], 201);
    } catch (PDOException $e) {
        responder(['ok' => false, 'error' => 'Ese correo ya está registrado.'], 409);
    }
}

if ($metodo === 'POST' && $accion === 'login') {
    $email = limpiarTexto($datos['email'] ?? '');
    $contrasena = $datos['contrasena'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();
    if (!$usuario || !password_verify($contrasena, $usuario['contrasena'])) {
        responder(['ok' => false, 'error' => 'Correo o contraseña incorrectos.'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['usuario_id'] = $usuario['id_usuario'];
    responder(['ok' => true, 'mensaje' => 'Inicio de sesión correcto.', 'usuario' => [
        'id' => $usuario['id_usuario'], 'nombre' => $usuario['primer_nombre'],
        'apellido' => $usuario['primer_apellido'], 'rol' => $usuario['rol'], 'email' => $usuario['email']
    ]]);
}

if ($metodo === 'POST' && $accion === 'logout') {
    session_destroy();
    responder(['ok' => true, 'mensaje' => 'Sesión cerrada.']);
}

if ($metodo === 'GET' && $accion === 'me') {
    $usuario = usuarioActual($pdo);
    if (!$usuario) responder(['ok' => false, 'error' => 'No hay una sesión activa.'], 401);
    responder(['ok' => true, 'usuario' => $usuario]);
}

if ($metodo === 'GET') {
    exigirRol($pdo, ['Administrador']);
    $stmt = $pdo->query('SELECT id_usuario, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, email, telefono, calle, direccion, zona, rol FROM usuarios ORDER BY id_usuario DESC');
    responder(['ok' => true, 'datos' => $stmt->fetchAll()]);
}

if ($metodo === 'POST') {
    exigirRol($pdo, ['Administrador']);
    if (strlen($datos['contrasena'] ?? '') < 4) responder(['ok' => false, 'error' => 'La contraseña debe tener al menos 4 caracteres.'], 422);
    $error = validarUsuario($datos);
    if ($error) responder(['ok' => false, 'error' => $error], 422);
    try {
        $stmt = $pdo->prepare('INSERT INTO usuarios (primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, email, telefono, contrasena, calle, direccion, zona, rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            limpiarTexto($datos['primer_nombre']), limpiarTexto($datos['segundo_nombre'] ?? ''),
            limpiarTexto($datos['primer_apellido']), limpiarTexto($datos['segundo_apellido'] ?? ''),
            limpiarTexto($datos['email']), limpiarTexto($datos['telefono'] ?? ''),
            password_hash($datos['contrasena'], PASSWORD_DEFAULT), limpiarTexto($datos['calle'] ?? ''),
            limpiarTexto($datos['direccion'] ?? ''), limpiarTexto($datos['zona'] ?? ''), $datos['rol']
        ]);
        responder(['ok' => true, 'mensaje' => 'Usuario creado correctamente.', 'id' => $pdo->lastInsertId()], 201);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') responder(['ok' => false, 'error' => 'Ese correo ya está registrado.'], 409);
        responder(['ok' => false, 'error' => 'No se pudo crear el usuario.'], 500);
    }
}

if (in_array($metodo, ['PUT', 'DELETE'], true)) {
    exigirRol($pdo, ['Administrador']);
    if ($id <= 0) responder(['ok' => false, 'error' => 'Falta el ID del usuario.'], 400);

    if ($metodo === 'DELETE') {
        try {
            $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id_usuario = ?');
            $stmt->execute([$id]);
            responder(['ok' => true, 'mensaje' => $stmt->rowCount() ? 'Usuario eliminado.' : 'Usuario no encontrado.']);
        } catch (PDOException $e) {
            responder(['ok' => false, 'error' => 'No se puede eliminar el usuario porque tiene incidencias u otros datos relacionados.'], 409);
        }
    }

    $error = validarUsuario($datos, true);
    if ($error) responder(['ok' => false, 'error' => $error], 422);
    $campos = 'primer_nombre=?, segundo_nombre=?, primer_apellido=?, segundo_apellido=?, email=?, telefono=?, calle=?, direccion=?, zona=?, rol=?';
    $params = [limpiarTexto($datos['primer_nombre']), limpiarTexto($datos['segundo_nombre'] ?? ''), limpiarTexto($datos['primer_apellido']), limpiarTexto($datos['segundo_apellido'] ?? ''), limpiarTexto($datos['email']), limpiarTexto($datos['telefono'] ?? ''), limpiarTexto($datos['calle'] ?? ''), limpiarTexto($datos['direccion'] ?? ''), limpiarTexto($datos['zona'] ?? ''), $datos['rol'], $id];
    if (!empty($datos['contrasena'])) {
        $campos .= ', contrasena=?';
        array_splice($params, -1, 0, password_hash($datos['contrasena'], PASSWORD_DEFAULT));
    }
    try {
        $stmt = $pdo->prepare("UPDATE usuarios SET $campos WHERE id_usuario=?");
        $stmt->execute($params);
        responder(['ok' => true, 'mensaje' => 'Usuario actualizado.']);
    } catch (PDOException $e) {
        responder(['ok' => false, 'error' => 'No se pudo actualizar el usuario.'], 500);
    }
}

responder(['ok' => false, 'error' => 'Operación no permitida.'], 405);
