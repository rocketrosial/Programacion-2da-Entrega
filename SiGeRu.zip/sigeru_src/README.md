# SiGeRU - Proyecto Final

Proyecto de 3ro de Bachillerato para la gestión de residuos urbanos.

## Tecnologías

- Frontend: HTML, CSS y JavaScript.
- Backend: PHP.
- Base de datos: MySQL.
- Testing: PHPUnit.
- Docker Compose: incluido para la entrega y despliegue.

## Ejecutar sin Docker (desarrollo)

1. Instalar PHP y MySQL (por ejemplo, mediante XAMPP).
2. Crear una base de datos llamada `sigeru`.
3. Importar primero `database/sigeru_estructura.sql`.
4. Importar después `database/datos_prueba.sql`.
5. Verificar que MySQL esté encendido.
6. Desde la carpeta del proyecto ejecutar:

```bash
php -S localhost:8080 router.php
```

7. Abrir `http://localhost:8080`.

La configuración local usa por defecto MySQL en `127.0.0.1:3306`, usuario `root` y contraseña vacía. Si tu instalación usa otros datos, se pueden definir `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` y `DB_PASS`.

## Usuarios de prueba

Todos usan contraseña: `1234`

- `admin@sigeru.local` - Administrador
- `vecino@sigeru.local` - Vecino
- `operario@sigeru.local` - Operario
- `cuadrilla@sigeru.local` - Cuadrilla

## Funciones

- Registro e inicio de sesión.
- CRUD de usuarios para el Administrador, incluyendo todos los roles.
- CRUD de contenedores.
- CRUD de camiones/flota.
- CRUD de centros de acopio.
- CRUD de maquinaria básica.
- Incidencias vinculadas siempre a un contenedor.
- Permisos comprobados también en el backend.
- Datos de prueba.
- Tests unitarios con PHPUnit.

## Incidencias

Una incidencia representa un problema de un contenedor. Se guarda el contenedor afectado, el usuario que la registra, prioridad, fecha, descripción y estado.

## Docker

Los archivos `Dockerfile` y `docker-compose.yml` se mantienen porque forman parte de los requisitos de entrega. Para el desarrollo diario no es necesario usar Docker si se ejecuta el proyecto con PHP y MySQL local.
