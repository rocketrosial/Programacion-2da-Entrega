let incidencias=[];
function puedeEditarIncidencia(){return ['Administrador','Operario','Cuadrilla'].includes(getUser()?.rol);}
function puedeEliminarIncidencia(){return ['Administrador','Operario'].includes(getUser()?.rol);}
async function cargarIncidencias(){
 const tbody=document.getElementById('tablaIncidencias');
 try{
  const d=await request('/api/gestion/index.php?recurso=incidencias');
  incidencias=d.datos;
  const editar=puedeEditarIncidencia();
  const eliminar=puedeEliminarIncidencia();
  tbody.innerHTML=incidencias.map(i=>{
   let acciones='<span class="muted">Consulta</span>';
   if(editar){acciones=`<button class="btn btn-light btn-small" onclick="editarIncidencia(${i.id_incidencia})">Editar</button>`;}
   if(eliminar){acciones+=`<button class="btn btn-danger btn-small" onclick="eliminarIncidencia(${i.id_incidencia})">Eliminar</button>`;}
   return `<tr><td>#${i.id_incidencia}</td><td>#${i.id_contenedor}</td><td>${escapeHTML(i.ubicacion)}</td><td>${escapeHTML(i.prioridad)}</td><td>${escapeHTML(i.fecha)}</td><td><span class="tag ${i.estado==='Pendiente'?'tag-yellow':i.estado==='Resuelta'?'tag-green':'tag-blue'}">${escapeHTML(i.estado)}</span></td><td>${escapeHTML(i.descripcion)}</td><td><div class="actions">${acciones}</div></td></tr>`;
  }).join('')||'<tr><td colspan="8" class="empty">No hay incidencias.</td></tr>';
 }catch(e){tbody.innerHTML=`<tr><td colspan="8" class="empty">${escapeHTML(e.message)}</td></tr>`}
}
function editarIncidencia(id){
 const i=incidencias.find(x=>Number(x.id_incidencia)===Number(id)); if(!i || !puedeEditarIncidencia())return;
 document.getElementById('incId').value=i.id_incidencia;
 document.getElementById('prioridad').value=i.prioridad;
 document.getElementById('estado').value=i.estado;
 document.getElementById('descripcion').value=i.descripcion;
 document.getElementById('modal').style.display='flex';
}
function cerrarIncModal(){document.getElementById('modal').style.display='none'}
async function eliminarIncidencia(id){
 if(!puedeEliminarIncidencia() || !confirm('¿Seguro que quieres eliminar esta incidencia?'))return;
 try{await request('/api/gestion/index.php?recurso=incidencias&id='+id,{method:'DELETE'});await cargarIncidencias();}catch(err){alert(err.message)}
}
document.addEventListener('DOMContentLoaded',()=>{
 if(!document.getElementById('tablaIncidencias'))return;
 if(!requireLogin())return;
 const nuevo=document.querySelector('[data-nueva-incidencia]');
 if(nuevo && !['Vecino','Operario','Administrador'].includes(getUser().rol))nuevo.style.display='none';
 cargarIncidencias();
 const form=document.getElementById('incForm');
 if(form) form.addEventListener('submit',async e=>{e.preventDefault();try{await request('/api/gestion/index.php?recurso=incidencias&id='+document.getElementById('incId').value,{method:'PUT',body:JSON.stringify({prioridad:document.getElementById('prioridad').value,estado:document.getElementById('estado').value,descripcion:document.getElementById('descripcion').value})});cerrarIncModal();cargarIncidencias()}catch(err){alert(err.message)}});
});
