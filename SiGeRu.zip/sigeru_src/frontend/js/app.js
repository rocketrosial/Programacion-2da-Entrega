const API = '/api';

function getUser(){
    try { return JSON.parse(localStorage.getItem('sigeru_usuario')) || null; }
    catch(e){ return null; }
}
function setUser(user){ localStorage.setItem('sigeru_usuario', JSON.stringify(user)); }
function clearUser(){ localStorage.removeItem('sigeru_usuario'); }
function escapeHTML(valor){
    return String(valor ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function mensaje(texto, ok=true){
    const box=document.getElementById('message'); if(!box) return;
    box.textContent=texto; box.className='message '+(ok?'ok':'error');
}
async function request(url, options={}){
    const response=await fetch(url,{credentials:'include',...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
    const data=await response.json().catch(()=>({ok:false,error:'Respuesta inválida del servidor.'}));
    if(!response.ok) throw new Error(data.error || 'Ocurrió un error.');
    return data;
}
function requireRole(roles){
    const user=requireLogin();
    if(!user)return null;
    if(!roles.includes(user.rol)){
        alert('No tienes permiso para entrar a esta sección.');
        window.location.href=roleHome(user.rol);
        return null;
    }
    return user;
}
function requireLogin(){
    const user=getUser();
    if(!user){ window.location.href='/pages/login.html'; return null; }
    return user;
}
function roleHome(role){
    if(role==='Administrador') return '/pages/dashboard-admin.html';
    if(role==='Cuadrilla') return '/pages/dashboard-cuadrilla.html';
    if(role==='Operario') return '/pages/dashboard-operario.html';
    return '/pages/dashboard-vecino.html';
}
function cerrarSesion(){
    fetch(API+'/usuarios/index.php?accion=logout',{method:'POST',credentials:'include'}).finally(()=>{clearUser();window.location.href='/pages/login.html';});
}
function setupUser(){
    const user=getUser();
    if(!user) return;
    const nombre=document.querySelector('[data-user-name]');
    const rol=document.querySelector('[data-user-role]');
    if(nombre) nombre.textContent=user.nombre+' '+(user.apellido||'');
    if(rol) rol.textContent=user.rol;
    const avatar=document.querySelector('[data-avatar]');
    if(avatar) avatar.textContent=(user.nombre||'U').charAt(0).toUpperCase();
    document.querySelectorAll('[data-role]').forEach(el=>{
        const roles=el.dataset.role.split(',');
        if(!roles.includes(user.rol)) el.style.display='none';
    });
}
function setupLogout(){ const b=document.getElementById('logout'); if(b)b.addEventListener('click',cerrarSesion); }

document.addEventListener('DOMContentLoaded',()=>{
    setupUser(); setupLogout();
    const register=document.getElementById('registerForm');
    if(register) register.addEventListener('submit',async e=>{
        e.preventDefault();
        const datos={primer_nombre:register.primer_nombre.value,primer_apellido:register.primer_apellido.value,email:register.email.value,contrasena:register.contrasena.value,zona:register.zona.value};
        try{await request(API+'/usuarios/index.php?accion=register',{method:'POST',body:JSON.stringify(datos)});mensaje('Cuenta creada. Ahora puedes iniciar sesión.');register.reset();}
        catch(err){mensaje(err.message,false);}
    });

    const login=document.getElementById('loginForm');
    if(login) login.addEventListener('submit',async e=>{
        e.preventDefault();
        try{
            const data=await request(API+'/usuarios/index.php?accion=login',{method:'POST',body:JSON.stringify({email:login.email.value,contrasena:login.contrasena.value})});
            setUser(data.usuario); window.location.href=roleHome(data.usuario.rol);
        }catch(err){mensaje(err.message,false);}
    });

    const incidentForm=document.getElementById('incidentForm');
    if(incidentForm){
        const user=getUser();
        if(!user || !['Vecino','Operario','Administrador'].includes(user.rol)){
            window.location.href=roleHome(user?.rol || 'Vecino');
            return;
        }
        cargarContenedoresParaIncidencia();
    }
    if(incidentForm) incidentForm.addEventListener('submit',async e=>{
        e.preventDefault();
        try{await request(API+'/gestion/index.php?recurso=incidencias',{method:'POST',body:JSON.stringify({id_contenedor:incidentForm.id_contenedor.value,prioridad:incidentForm.prioridad.value,descripcion:incidentForm.descripcion.value})});mensaje('Incidencia registrada correctamente.');incidentForm.reset();}
        catch(err){mensaje(err.message,false);}
    });
});

async function cargarContenedoresParaIncidencia(){
    const select=document.getElementById('id_contenedor'); if(!select)return;
    try{const d=await request(API+'/gestion/index.php?recurso=contenedores');select.innerHTML='<option value="">Seleccionar contenedor</option>'+d.datos.map(c=>`<option value="${c.id_contenedor}">#${c.id_contenedor} - ${escapeHTML(c.ubicacion)} (${escapeHTML(c.estado)})</option>`).join('');}
    catch(e){select.innerHTML='<option>No se pudieron cargar los contenedores</option>';}
}
