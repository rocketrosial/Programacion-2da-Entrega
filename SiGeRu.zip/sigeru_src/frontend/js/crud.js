const CRUD = {
    usuarios:{url:'/api/usuarios/index.php', id:'id_usuario', title:'Usuarios', columns:[['id_usuario','ID'],['primer_nombre','Nombre'],['primer_apellido','Apellido'],['email','Email'],['rol','Rol']], form:'usuarioForm', roles:['Administrador'], writeRoles:['Administrador']},
    contenedores:{url:'/api/gestion/index.php?recurso=contenedores', id:'id_contenedor', title:'Contenedores', columns:[['id_contenedor','ID'],['ubicacion','Ubicación'],['zona','Zona'],['estado','Estado'],['capacidad','Capacidad']], form:'contenedorForm', roles:['Administrador','Operario'], writeRoles:['Administrador','Operario']},
    camiones:{url:'/api/gestion/index.php?recurso=camiones', id:'id_camion', title:'Camiones / Flota', columns:[['id_camion','ID'],['matricula','Matrícula'],['estado','Estado'],['capacidad_carga','Capacidad'],['disponibilidad','Disponibilidad']], form:'camionForm', roles:['Administrador','Operario','Cuadrilla'], writeRoles:['Administrador','Operario']},
    centros:{url:'/api/gestion/index.php?recurso=centros', id:'id_centro', title:'Centros de acopio', columns:[['id_centro','ID'],['nombre','Nombre'],['ubicacion','Ubicación']], form:'centroForm', roles:['Administrador','Operario','Cuadrilla'], writeRoles:['Administrador','Operario']},
    maquinaria:{url:'/api/gestion/index.php?recurso=maquinaria', id:'id_maquinaria', title:'Maquinaria básica', columns:[['id_maquinaria','ID'],['nombre','Nombre'],['tipo','Tipo'],['estado','Estado']], form:'maquinariaForm', roles:['Administrador','Operario','Cuadrilla'], writeRoles:['Administrador','Operario']}
};

let lista=[];
function val(id){return document.getElementById(id)?.value.trim() || '';}
function formData(tipo){
    if(tipo==='usuarios') return {primer_nombre:val('primer_nombre'),segundo_nombre:val('segundo_nombre'),primer_apellido:val('primer_apellido'),segundo_apellido:val('segundo_apellido'),email:val('email'),telefono:val('telefono'),contrasena:val('contrasena'),calle:val('calle'),direccion:val('direccion'),zona:val('zona'),rol:val('rol')};
    if(tipo==='contenedores') return {ubicacion:val('ubicacion'),zona:val('zona'),calle:val('calle'),estado:val('estado'),capacidad:val('capacidad'),fecha_deteccion:val('fecha_deteccion'),zona_incidencia:val('zona_incidencia')};
    if(tipo==='camiones') return {matricula:val('matricula'),estado:val('estado'),capacidad_carga:val('capacidad_carga'),disponibilidad:val('disponibilidad'),fecha_asignacion:val('fecha_asignacion'),hora_inicio:val('hora_inicio'),hora_fin:val('hora_fin')};
    if(tipo==='centros') return {nombre:val('nombre'),ubicacion:val('ubicacion')};
    return {nombre:val('maquinaria_nombre'),tipo:val('maquinaria_tipo'),estado:val('maquinaria_estado')};
}
function setForm(tipo,obj){
    const campos=Object.keys(formData(tipo));
    campos.forEach(c=>{const id=tipo==='maquinaria' && c==='nombre'?'maquinaria_nombre':c; const el=document.getElementById(id); if(el)el.value=obj[c]??'';});
    if(tipo==='usuarios') document.getElementById('contrasena').value='';
}
function puedeEditar(tipo){return CRUD[tipo].writeRoles.includes(getUser()?.rol);}
async function cargarCRUD(tipo){
    const cfg=CRUD[tipo], tbody=document.getElementById('tabla');
    try{const d=await request(cfg.url);lista=d.datos;renderTabla(tipo);actualizarBotonNuevo(tipo);}
    catch(e){tbody.innerHTML=`<tr><td colspan="10" class="empty">${escapeHTML(e.message)}</td></tr>`;}
}
function actualizarBotonNuevo(tipo){
    const boton=document.querySelector('[data-nuevo]');
    if(boton) boton.style.display=puedeEditar(tipo)?'inline-block':'none';
}
function renderTabla(tipo){
    const cfg=CRUD[tipo], tbody=document.getElementById('tabla'), puede=puedeEditar(tipo);
    tbody.innerHTML=lista.map(o=>{
        const acciones=puede?`<button class="btn btn-light btn-small" onclick="editar('${tipo}',${o[cfg.id]})">Editar</button><button class="btn btn-danger btn-small" onclick="eliminar('${tipo}',${o[cfg.id]})">Eliminar</button>`:'<span class="muted">Solo consulta</span>';
        return `<tr>${cfg.columns.map(c=>`<td>${escapeHTML(o[c[0]])}</td>`).join('')}<td><div class="actions">${acciones}</div></td></tr>`;
    }).join('') || `<tr><td colspan="10" class="empty">No hay registros.</td></tr>`;
}
function abrirModal(tipo,id=0){ 
    if(!puedeEditar(tipo)){alert('Tu rol solo permite consultar estos datos.');return;} 
    document.getElementById('modal').style.display='flex'; 
    document.getElementById(CRUD[tipo].form)?.reset(); 
    document.getElementById('registroId').value=id || ''; 
    document.getElementById('modalTitle').textContent=id?'Editar registro':'Nuevo registro'; 
    if(id){const o=lista.find(x=>Number(x[CRUD[tipo].id])===Number(id)); if(o)setForm(tipo,o);} 
}
function cerrarModal(){document.getElementById('modal').style.display='none';}
function editar(tipo,id){abrirModal(tipo,id)}
async function eliminar(tipo,id){
    if(!puedeEditar(tipo))return;
    if(!confirm('¿Seguro que quieres eliminar este registro?'))return;
    try{await request(CRUD[tipo].url+(CRUD[tipo].url.includes('?')?'&':'?')+'id='+id,{method:'DELETE'});await cargarCRUD(tipo);}
    catch(e){alert(e.message);}
}
document.addEventListener('DOMContentLoaded',()=>{
    const tipo=document.body.dataset.crud; if(!tipo)return;
    const user=requireLogin(); if(!user)return;
    if(!CRUD[tipo].roles.includes(user.rol)){alert('No tienes permiso para entrar a esta sección.');window.location.href=roleHome(user.rol);return;}
    const form=document.getElementById(CRUD[tipo].form);
    if(form) form.addEventListener('submit',async e=>{
        e.preventDefault(); if(!puedeEditar(tipo))return;
        const id=val('registroId');
        try{await request(CRUD[tipo].url+(id?(CRUD[tipo].url.includes('?')?'&':'?')+'id='+id:''),{method:id?'PUT':'POST',body:JSON.stringify(formData(tipo))});cerrarModal();await cargarCRUD(tipo);}
        catch(err){alert(err.message);}
    });
    cargarCRUD(tipo);
});

