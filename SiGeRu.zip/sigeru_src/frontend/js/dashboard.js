document.addEventListener('DOMContentLoaded',async()=>{
    const user=requireLogin(); if(!user)return;
    const title=document.getElementById('welcome'); if(title)title.textContent='Hola, '+user.nombre+' 👋';
    try{
        const [c,i]=await Promise.all([request('/api/gestion/index.php?recurso=contenedores'),request('/api/gestion/index.php?recurso=incidencias')]);
        const a=document.getElementById('countCont'); if(a)a.textContent=c.datos.length;
        const b=document.getElementById('countInc'); if(b)b.textContent=i.datos.length;
        const pend=i.datos.filter(x=>x.estado==='Pendiente').length; const p=document.getElementById('countPend'); if(p)p.textContent=pend;
        const countCamiones=document.getElementById('countCamiones');
        if(countCamiones){const camiones=await request('/api/gestion/index.php?recurso=camiones');countCamiones.textContent=camiones.datos.length;}
    }catch(e){console.error(e);}
});
