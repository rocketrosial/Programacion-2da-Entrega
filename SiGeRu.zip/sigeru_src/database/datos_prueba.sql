USE sigeru;

INSERT INTO usuarios (primer_nombre, primer_apellido, email, contrasena, rol, zona) VALUES
('Ana','Administrador','admin@sigeru.local','$2y$12$/SkTEg4y2ACVcCvVHKY54ecrtV43tOBwcmHKgtUFrq0TvcgQKofrC','Administrador','Centro'),
('Juan','Perez','vecino@sigeru.local','$2y$12$/SkTEg4y2ACVcCvVHKY54ecrtV43tOBwcmHKgtUFrq0TvcgQKofrC','Vecino','Centro'),
('Carlos','Gomez','operario@sigeru.local','$2y$12$/SkTEg4y2ACVcCvVHKY54ecrtV43tOBwcmHKgtUFrq0TvcgQKofrC','Operario','Norte'),
('Lucia','Diaz','cuadrilla@sigeru.local','$2y$12$/SkTEg4y2ACVcCvVHKY54ecrtV43tOBwcmHKgtUFrq0TvcgQKofrC','Cuadrilla','Sur');

INSERT INTO tipo_residuo (nombre, descripcion) VALUES ('Residuo común','Residuos domésticos comunes'),('Reciclable','Plástico, papel y cartón');
INSERT INTO contenedores (zona_incidencia, fecha_deteccion, estado, capacidad, ubicacion, zona, calle, id_residuo) VALUES
('Centro','2026-09-10','Funcional',1100,'Av. 18 de Julio 1234','Centro','18 de Julio',1),
('Norte','2026-09-11','Lleno',1100,'Av. Italia 2450','Norte','Av. Italia',1),
('Sur','2026-09-12','Dañado',800,'Rambla 800','Sur','Rambla',2),
('Centro','2026-09-12','Funcional',1000,'Colonia 1550','Centro','Colonia',2);
INSERT INTO camiones (matricula, disponibilidad, estado, capacidad_carga, fecha_asignacion, hora_inicio, hora_fin) VALUES
('SIR-001','Disponible','Operativo',10000,'2026-09-01','07:00','15:00'),
('SIR-002','En recorrido','Operativo',12000,'2026-09-02','06:30','14:30'),
('SIR-003','No disponible','Mantenimiento',8000,NULL,NULL,NULL);
INSERT INTO centro_acopio (nombre, ubicacion) VALUES ('Centro Acopio Norte','Av. de las Instrucciones 1200'),('Centro Acopio Sur','Camino Carrasco 2200');
INSERT INTO maquinaria (estado, tipo, nombre) VALUES ('Operativa','Compactadora','Compactadora 01'),('Operativa','Pala cargadora','Pala 01'),('Mantenimiento','Trituradora','Trituradora 02');
INSERT INTO incidencias (id_contenedor,id_usuario,prioridad,fecha,descripcion,estado) VALUES
(2,2,'Alta','2026-09-11','El contenedor está completamente lleno.','Pendiente'),
(3,2,'Media','2026-09-12','La tapa está rota.','En revisión');
