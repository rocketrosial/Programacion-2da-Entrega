CREATE DATABASE IF NOT EXISTS sigeru CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sigeru;

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    primer_nombre VARCHAR(50) NOT NULL,
    segundo_nombre VARCHAR(50),
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50),
    email VARCHAR(120) NOT NULL UNIQUE,
    telefono VARCHAR(30),
    contrasena VARCHAR(255) NOT NULL,
    calle VARCHAR(100), direccion VARCHAR(150), zona VARCHAR(100),
    rol ENUM('Administrador','Vecino','Cuadrilla','Operario') NOT NULL
);

CREATE TABLE tipo_residuo (
    id_residuo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    descripcion TEXT
);

CREATE TABLE contenedores (
    id_contenedor INT AUTO_INCREMENT PRIMARY KEY,
    zona_incidencia VARCHAR(100), fecha_deteccion DATE,
    estado VARCHAR(30) NOT NULL, capacidad DECIMAL(10,2) NOT NULL,
    ubicacion VARCHAR(150) NOT NULL, zona VARCHAR(100), calle VARCHAR(100),
    id_residuo INT NULL,
    FOREIGN KEY (id_residuo) REFERENCES tipo_residuo(id_residuo)
);

CREATE TABLE camiones (
    id_camion INT AUTO_INCREMENT PRIMARY KEY,
    matricula VARCHAR(20) NOT NULL UNIQUE,
    disponibilidad VARCHAR(30) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    capacidad_carga DECIMAL(10,2) NOT NULL,
    fecha_asignacion DATE, hora_inicio TIME, hora_fin TIME
);

CREATE TABLE centro_acopio (
    id_centro INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ubicacion VARCHAR(150) NOT NULL
);

CREATE TABLE maquinaria (
    id_maquinaria INT AUTO_INCREMENT PRIMARY KEY,
    estado VARCHAR(30) NOT NULL,
    tipo VARCHAR(80) NOT NULL,
    nombre VARCHAR(100) NOT NULL
);

CREATE TABLE incidencias (
    id_incidencia INT AUTO_INCREMENT PRIMARY KEY,
    id_contenedor INT NOT NULL,
    id_usuario INT NOT NULL,
    prioridad VARCHAR(30) NOT NULL DEFAULT 'Media',
    fecha DATE NOT NULL,
    descripcion TEXT NOT NULL,
    estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente',
    FOREIGN KEY (id_contenedor) REFERENCES contenedores(id_contenedor),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

CREATE TABLE cuadrillas (
    id_cuadrilla INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL
);
CREATE TABLE rutas (
    id_ruta INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(255), distancia DECIMAL(10,2), nombre VARCHAR(100)
);
CREATE TABLE zonas (
    id_zona INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL, zona_asignada VARCHAR(100)
);
CREATE TABLE plantas_procesamiento (
    id_planta INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL, ubicacion VARCHAR(150), calle VARCHAR(100), zona VARCHAR(100)
);
CREATE TABLE instalacion (
    id_instalacion INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL, ubicacion VARCHAR(150), calle VARCHAR(100), zona VARCHAR(100),
    capacidad_actual DECIMAL(10,2), capacidad_max DECIMAL(10,2)
);
CREATE TABLE vertedero (
    id_vertedero INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100), ubicacion VARCHAR(150)
);
CREATE TABLE notificaciones (
    id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
    id_vecino INT NOT NULL, estado VARCHAR(30), descripcion TEXT, fecha DATE,
    FOREIGN KEY (id_vecino) REFERENCES usuarios(id_usuario)
);
CREATE TABLE asignacion_cuadrilla (
    id_cuadrilla INT NOT NULL, id_camion INT NOT NULL, fecha_ingreso DATE,
    PRIMARY KEY (id_cuadrilla,id_camion),
    FOREIGN KEY (id_cuadrilla) REFERENCES cuadrillas(id_cuadrilla),
    FOREIGN KEY (id_camion) REFERENCES camiones(id_camion)
);
CREATE TABLE ruta_cuadrilla (
    id_cuadrilla INT NOT NULL, id_ruta INT NOT NULL,
    PRIMARY KEY (id_cuadrilla,id_ruta),
    FOREIGN KEY (id_cuadrilla) REFERENCES cuadrillas(id_cuadrilla),
    FOREIGN KEY (id_ruta) REFERENCES rutas(id_ruta)
);
CREATE TABLE ruta_zona (
    id_ruta INT NOT NULL, id_zona INT NOT NULL,
    PRIMARY KEY (id_ruta,id_zona),
    FOREIGN KEY (id_ruta) REFERENCES rutas(id_ruta),
    FOREIGN KEY (id_zona) REFERENCES zonas(id_zona)
);
CREATE TABLE camion_ruta (
    id_camion INT NOT NULL, id_ruta INT NOT NULL,
    PRIMARY KEY (id_camion,id_ruta),
    FOREIGN KEY (id_camion) REFERENCES camiones(id_camion),
    FOREIGN KEY (id_ruta) REFERENCES rutas(id_ruta)
);
CREATE TABLE asignacion_incidencia (
    id_incidencia INT NOT NULL, id_cuadrilla INT NOT NULL,
    PRIMARY KEY (id_incidencia,id_cuadrilla),
    FOREIGN KEY (id_incidencia) REFERENCES incidencias(id_incidencia),
    FOREIGN KEY (id_cuadrilla) REFERENCES cuadrillas(id_cuadrilla)
);
