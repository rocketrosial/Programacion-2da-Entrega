<?php
echo "PHP FUNCIONA";